package com.example.barsukpr15;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class tv4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tv4);
    }
}